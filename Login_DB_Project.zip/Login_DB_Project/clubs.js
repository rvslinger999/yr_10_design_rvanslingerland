console.log("in java script")

const clubform = document.getElementById("clubs_form")
const clublist = document.getElementById("clublist")

console.log (clublist)

clubform.addEventListener("submit", (e) => {

	console.log(e)
	e.preventDefault() //Stops page from reloading")

	user = clubform["user_name"].value

	club = clubform["club_name"].value

	trait = clubform["traits"].value

	description = clubform["club_description"].value

	//Copy to database
	newPostKey = database.ref().child('clubs').push().key;
	clubdata = {


        name: club,
        trait: trait,
        description: description,


    }

    update = {

    }

update['/clubs/'+newPostKey] = clubdata
		database.ref().update(update)

	//Close the modal
	const modal = document.querySelector('#add_club_modal'); 
	//M is the materialize tool box that I have access to since I loaded the resources
	//Modal is the set tools inside M for modals
	//getInstance is a special function that I pass the modal object to
	//close()
	M.Modal.getInstance(modal).close();
	//Clears the content in the modal
	clubform.reset()

});

function createCard(dataOBJ){


	card = `


    <div class="col s12 m6">
      <div class="card small blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">${dataOBJ["name"]}</span>
          <p>${dataOBJ["description"]}</p>
        </div>
        <div class="card-action">
          <a>${dataOBJ["trait"]}</a>
        </div>
      </div>
    </div>`


	return card
}

//on is a function that creates a connection with the database and "on child added" runs the code
//when you first load the page it accesses everything and then waits to see if there are any changes
database.ref('clubs').on("value",(snapshot)=> {

	clublist.innerHTML = ""
	//console.log(snapshot.val())
	data = snapshot.val()
	for (key in data){
		clublist.innerHTML = clublist.innerHTML + createCard(data[key])
	}


});